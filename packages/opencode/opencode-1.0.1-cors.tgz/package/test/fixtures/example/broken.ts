// Test fixture for ListTool
